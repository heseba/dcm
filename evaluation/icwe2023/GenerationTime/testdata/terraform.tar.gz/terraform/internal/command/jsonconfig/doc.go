// Package jsonconfig implements methods for outputting a configuration snapshot
// in machine-readable json format
package jsonconfig
